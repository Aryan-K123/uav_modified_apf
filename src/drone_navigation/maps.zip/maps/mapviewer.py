import open3d as o3d

def visualize_pcd(file_path):
    """
    Reads and visualizes a .pcd file using Open3D.

    Args:
        file_path (str): Path to the .pcd file.
    """
    # Read the .pcd file
    try:
        pcd = o3d.io.read_point_cloud(file_path)
        print("Successfully read the point cloud file.")
    except Exception as e:
        print(f"Error reading point cloud file: {e}")
        return

    # Print point cloud details
    print(pcd)

    # Check if the point cloud is empty
    if not pcd.has_points():
        print("The point cloud is empty.")
        return

    # Visualize the point cloud
    print("Visualizing the point cloud...")
    o3d.visualization.draw_geometries([pcd],
                                      zoom=0.8,
                                      front=[0, 0, -1],
                                      lookat=[0, 0, 0],
                                      up=[0, -1, 0])

if __name__ == "__main__":
    # Replace with the path to your .pcd file
    file_path = "map.pcd"
    visualize_pcd(file_path)

